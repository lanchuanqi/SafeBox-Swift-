//
//  AlbumViewController.swift
//  Final
//
//  Created by logan on 7/29/15.
//  Copyright (c) 2015 logan. All rights reserved.
//

import UIKit
import Photos
import CoreData

class AlbumViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    var barTitle: String = ""
    var photosAlbum: Array<AllPhotos> = []
    var selectedAlbum: Model!
    
    @IBAction func CameraButton(sender: AnyObject) {
        if (UIImagePickerController.isSourceTypeAvailable(.Camera)){
            let picker: UIImagePickerController = UIImagePickerController()
            picker.sourceType = UIImagePickerControllerSourceType.Camera
            picker.delegate = self
            picker.allowsEditing = false
            self.presentViewController(picker, animated: true, completion: nil)
        }
        else{
            let alert = UIAlertController(title: "Error", message: "There is no camera available", preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: "Okey", style: .Default, handler: {(alertAction)in
                alert.dismissViewControllerAnimated(true, completion: nil)
            }))
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }

    @IBAction func FileButton(sender: AnyObject) {
        let picker: UIImagePickerController = UIImagePickerController()
        picker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        picker.delegate = self
        picker.allowsEditing = false
        self.presentViewController(picker, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var fileBarButtonItem: UIBarButtonItem!
    @IBOutlet weak var cameraBarButtonItem: UIBarButtonItem!
    @IBOutlet weak var ImageCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let rightButtonItems = [fileBarButtonItem, cameraBarButtonItem]
        navigationItem.leftBarButtonItem = nil
        navigationItem.rightBarButtonItems! = rightButtonItems as! [UIBarButtonItem]
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(animated: Bool) {
        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let context: NSManagedObjectContext = appDel.managedObjectContext!
        let freq = NSFetchRequest(entityName: "Photo")
        freq.predicate = NSPredicate(format: "album == %@", selectedAlbum)
        photosAlbum = (try! context.executeFetchRequest(freq)) as! Array<AllPhotos>
        ImageCollectionView.reloadData()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        self.navigationController?.hidesBarsOnTap = false
        self.navigationItem.title = barTitle
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        //#warning Incomplete method implementation -- Return the number of sections
        return 1
    }
    
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //#warning Incomplete method implementation -- Return the number of items in the section
        return photosAlbum.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = ImageCollectionView.dequeueReusableCellWithReuseIdentifier("ImageCell", forIndexPath: indexPath) as! ImageCollectionViewCell
        let img = photosAlbum[indexPath.item]
        cell.setImage(UIImage(data: img.data))
        
        
        return cell
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier! as String == "showFullSize"{
            let fullsizeController = segue.destinationViewController as! FullSizeImageViewController
            let indexPath = self.ImageCollectionView.indexPathForCell(sender as! UICollectionViewCell)
            let photo = photosAlbum[indexPath!.item]
            fullsizeController.selectedImage = photo
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let context: NSManagedObjectContext = appDel.managedObjectContext!
        let en = NSEntityDescription.entityForName("Photo", inManagedObjectContext: context)
        let newAlbum = AllPhotos(entity: en!, insertIntoManagedObjectContext: context)
        newAlbum.data = UIImageJPEGRepresentation(image, 0.9)
        newAlbum.album = selectedAlbum
        do {
            // edit
        
            
        
            // save context
            try context.save()
        } catch _ {
        }
        
        picker.dismissViewControllerAnimated(true, completion: nil)
        ImageCollectionView.reloadData()
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
}
