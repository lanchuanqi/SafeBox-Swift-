//
//  CustomTabBarController.swift
//  Final
//
//  Created by logan on 8/10/15.
//  Copyright (c) 2015 logan. All rights reserved.
//


import UIKit


class CustomTabBarController: UITabBarController {
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let identifier = segue.identifier where identifier == "LoginSegue" {
            if let loginNavController = segue.destinationViewController as? UINavigationController,
               let loginVieWController = loginNavController.topViewController as? LoginViewController,
               let loginViewControllerDelegate = sender as? LoginViewControllerDelegate {
               loginVieWController.delegate = loginViewControllerDelegate
            }
        }
        else {
            super.prepareForSegue(segue, sender: sender)
        }
    }
}
