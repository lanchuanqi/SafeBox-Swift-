//
//  FullSizeImageViewController.swift
//  Final
//
//  Created by logan on 7/30/15.
//  Copyright (c) 2015 logan. All rights reserved.
//

import UIKit
import CoreData

class FullSizeImageViewController: UIViewController, UIScrollViewDelegate {

    var selectedImage: AllPhotos!
    var photosAlbum: Array<AllPhotos> = []
    
    @IBAction func CancelButton(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    func image(image: UIImage, didFinishSavingWithError error: NSErrorPointer, contextInfo:UnsafePointer<Void>) {
    }
    @IBAction func saveButton(sender: AnyObject) {
        UIImageWriteToSavedPhotosAlbum(FullImageView.image!, self, "image:didFinishSavingWithError:contextInfo:", nil)
        let alert = UIAlertController(title: "Image", message: "Saved Successful", preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "Okey", style: .Default, handler: {(alertAction)in
            alert.dismissViewControllerAnimated(true, completion: nil)
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    @IBAction func TrashButton(sender: AnyObject) {
        let alert = UIAlertController(title: "Delete Image", message: "Are you sure you want to delete this image?", preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .Default, handler: {(alertAction) in
            let appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let context: NSManagedObjectContext = appDel.managedObjectContext!
            context.deleteObject(self.selectedImage)
            do {
                try context.save()
            } catch _ {
            }
            self.dismissViewControllerAnimated(true, completion: nil)
            self.navigationController?.popViewControllerAnimated(true)
        }))
        alert.addAction(UIAlertAction(title: "No", style: .Cancel, handler: {(alertAction) in
            self.dismissViewControllerAnimated(true, completion: nil)
        }))
        
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBOutlet weak var FullImageView: UIImageView!
    
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return FullImageView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.hidesBarsOnTap = true

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)

        FullImageView.image = UIImage(data: selectedImage.data)
    }
    
}
